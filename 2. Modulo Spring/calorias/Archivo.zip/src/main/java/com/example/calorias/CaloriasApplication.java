package com.example.calorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaloriasApplication {

    public static void main(String[] args) {
        SpringApplication.run(CaloriasApplication.class, args);
    }

}
