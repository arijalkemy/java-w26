package com.calculoEdad.calculoEdad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculoEdadApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculoEdadApplication.class, args);
	}

}
