package org.example.personajesdestarwars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonajesDeStarWarsApplicationTests {

    @Test
    void contextLoads() {
    }

}
