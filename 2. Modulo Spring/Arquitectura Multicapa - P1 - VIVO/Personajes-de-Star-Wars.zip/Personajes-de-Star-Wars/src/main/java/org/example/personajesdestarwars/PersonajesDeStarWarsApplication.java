package org.example.personajesdestarwars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonajesDeStarWarsApplication {

    public static void main(String[] args) {
        SpringApplication.run(PersonajesDeStarWarsApplication.class, args);
    }

}
