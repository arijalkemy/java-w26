package com.javabootcamp.linktracker.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MensajeDTO {
    private String mensajeDelServidor;
}
