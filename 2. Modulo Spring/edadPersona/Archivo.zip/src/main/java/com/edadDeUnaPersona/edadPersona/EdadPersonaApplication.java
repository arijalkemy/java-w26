package com.edadDeUnaPersona.edadPersona;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdadPersonaApplication {


	public static void main(String[] args) {
		SpringApplication.run(EdadPersonaApplication.class, args);
	}

}
