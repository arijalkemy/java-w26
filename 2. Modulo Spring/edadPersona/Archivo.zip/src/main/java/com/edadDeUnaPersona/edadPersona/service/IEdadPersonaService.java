package com.edadDeUnaPersona.edadPersona.service;

public interface IEdadPersonaService {

    public int obtenerEdad(int dia, int mes, int anio);

}
