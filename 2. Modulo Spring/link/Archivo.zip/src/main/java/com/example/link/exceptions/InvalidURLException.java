package com.example.link.exceptions;

public class InvalidURLException extends RuntimeException{

    public InvalidURLException(String message) {
        super(message);
    }
}
