package com.example.link.DTOs;


import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class LinkResponseDTO {

    public int id;

}
