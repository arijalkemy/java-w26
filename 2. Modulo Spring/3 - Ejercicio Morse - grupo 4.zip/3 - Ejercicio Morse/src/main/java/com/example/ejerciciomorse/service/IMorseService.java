package com.example.ejerciciomorse.service;

public interface IMorseService {

    public String convertToWord( String morse );

    public String convertToMorse( String word );
}
