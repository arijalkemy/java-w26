package com.example.multicapatemplate.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Servicio {
    private String descripcion;
    private LocalDate fecha;
    private int kilometros;
}
