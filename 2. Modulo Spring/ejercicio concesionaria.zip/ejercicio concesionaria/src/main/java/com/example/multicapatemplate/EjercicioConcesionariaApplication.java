package com.example.multicapatemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioConcesionariaApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjercicioConcesionariaApplication.class, args);
    }

}
