package com.spring.deportistas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeportistasApplicationTests {

    @Test
    void contextLoads() {
    }

}
