package com.example._04_deportista.controladores;

import com.example._04_deportista.dominio.DTO.PersonaDeportistaDTO;
import com.example._04_deportista.dominio.Persona;
import com.example._04_deportista.servicios.IPersona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController("/persona")
public class PersonaController {
    @Autowired
    IPersona iPersona;

    @GetMapping("/findSportsPersons")
    public ResponseEntity<List<PersonaDeportistaDTO>> obtenerPersonas(){
        List<PersonaDeportistaDTO> personasDTO = new ArrayList<>();

        for (Persona persona: iPersona.obtenerPersonas()){
            PersonaDeportistaDTO personaDTO = new PersonaDeportistaDTO();

            personaDTO.setNombre(persona.getNombre());
            personaDTO.setApellido(persona.getApellido());
            personaDTO.setNombreDeporte(persona.getDeporte().getNombre());

            personasDTO.add(personaDTO);
        }

        if(personasDTO.size() == 0)
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);

        return new ResponseEntity<>(personasDTO, HttpStatus.OK);
    }

}
