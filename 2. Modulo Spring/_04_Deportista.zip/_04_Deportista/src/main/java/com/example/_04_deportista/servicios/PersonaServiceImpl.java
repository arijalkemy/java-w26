package com.example._04_deportista.servicios;

import com.example._04_deportista.dominio.Deporte;
import com.example._04_deportista.dominio.Persona;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PersonaServiceImpl implements IPersona{

    static List<Persona> personas;
    static {
        personas = new ArrayList<>();
        personas.add(new Persona("marcos", "bellotti", 22));
        personas.add(new Persona("jorge", "andrada", 20, new Deporte("futbol", 4)));
        personas.add(new Persona("julian", "alvarez", 25, new Deporte("voley", 4)));
    }

    @Override
    public List<Persona> obtenerPersonas() {
        return personas.stream()
                .filter(p->p.getDeporte() != null)
                .toList();
    }
}
