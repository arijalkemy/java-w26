package com.example._04_deportista.servicios;

import com.example._04_deportista.dominio.Deporte;

import java.util.List;

public interface IDeporte {
    public List<Deporte> obtenerDeportes();
    public int obtenerNivelDeDeporte(String nombre);

}
