package com.example._04_deportista.servicios;

import com.example._04_deportista.dominio.Persona;

import java.util.List;

public interface IPersona {
    public List<Persona> obtenerPersonas();
}
