package org.responseentity.agenciaautos.service;

import org.responseentity.agenciaautos.dto.VehicleDTO;
import org.responseentity.agenciaautos.entity.VehicleEntity;
import org.responseentity.agenciaautos.mapper.VehicleMapper;
import org.responseentity.agenciaautos.repository.VehiculeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class VehicleServiceImp implements VehicleService{
    @Autowired
    VehiculeRepository repository;

    @Override
    public List<VehicleDTO> getAllVehicles() {
        return repository.getAllVehicles()
                .stream()
                .map(vehicleEntity -> VehicleMapper.entityToDTO(vehicleEntity))
                .toList();
    }

    @Override
    public VehicleDTO getVehicleById(UUID id) {
        return null;
    }

    @Override
    public List<VehicleDTO> getVehiclesByPriceRange(int priceLowRange, int priceHighRange) {
        return null;
    }

    @Override
    public List<VehicleDTO> getVehiclesByDateRange(LocalDate dateLowRange, LocalDate dateHighRange) {
        return null;
    }

    @Override
    public VehicleDTO addVehicle(VehicleDTO vehicleDTO) {
        VehicleEntity ve = VehicleMapper.dtoToEntity(vehicleDTO);
        VehicleEntity ve1 = repository.addVehicle(ve);

        VehicleDTO vd = VehicleMapper.entityToDTO(ve1);
        return vd;
    }
}
