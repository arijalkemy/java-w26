package org.responseentity.agenciaautos.mapper;


import org.responseentity.agenciaautos.dto.VehicleDTO;
import org.responseentity.agenciaautos.entity.VehicleEntity;

public class VehicleMapper {
    public static VehicleDTO entityToDTO(VehicleEntity vehicleEntity){
        org.responseentity.agenciaautos.dto.VehicleDTO vehicleDTO = new org.responseentity.agenciaautos.dto.VehicleDTO();
        vehicleDTO.setId(vehicleEntity.getId());
        vehicleDTO.setModel(vehicleEntity.getModel());
        vehicleDTO.setManufacturingDate(vehicleEntity.getManufacturingDate());
        vehicleDTO.setNumberOfKilometers(vehicleEntity.getNumberOfKilometers());
        vehicleDTO.setDoors(vehicleEntity.getDoors());
        vehicleDTO.setPrice(vehicleEntity.getPrice());
        vehicleDTO.setCurrency(vehicleEntity.getCurrency());
        vehicleDTO.setServices(vehicleEntity.getServices());
        vehicleDTO.setCountOfOwners(vehicleEntity.getCountOfOwners());

        return vehicleDTO;
    }

    public static VehicleEntity dtoToEntity(VehicleDTO dto){
        VehicleEntity et = new VehicleEntity();
        et.setId(dto.getId());
        et.setBrand(dto.getBrand());
        et.setModel(dto.getModel());
        et.setManufacturingDate(dto.getManufacturingDate());
        et.setNumberOfKilometers(dto.getNumberOfKilometers());
        et.setDoors(dto.getDoors());
        et.setPrice(dto.getPrice());
        et.setCurrency(dto.getCurrency());
        et.setCountOfOwners(dto.getCountOfOwners());

        return et;
    }
}
