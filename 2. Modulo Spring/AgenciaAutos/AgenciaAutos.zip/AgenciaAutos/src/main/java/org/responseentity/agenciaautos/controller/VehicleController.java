package org.responseentity.agenciaautos.controller;

import org.responseentity.agenciaautos.dto.VehicleDTO;
import org.responseentity.agenciaautos.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/vehicles")
public class VehicleController {

    @Autowired
    VehicleService vehicleService;

    @GetMapping("")
    public List<VehicleDTO> getAllVehicles(){
        return vehicleService.getAllVehicles();
    }

    @PostMapping("")
    public ResponseEntity<?> insertVehicle(@RequestBody VehicleDTO vehicle){
        vehicleService.addVehicle(vehicle);
        return new ResponseEntity<>(vehicle, HttpStatus.OK);
    }
}
