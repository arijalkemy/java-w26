package org.responseentity.agenciaautos.service;

import org.responseentity.agenciaautos.dto.VehicleDTO;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface VehicleService {
    List<VehicleDTO> getAllVehicles();
    VehicleDTO getVehicleById(UUID id);
    List<VehicleDTO> getVehiclesByPriceRange(int priceLowRange, int priceHighRange);
    List<VehicleDTO> getVehiclesByDateRange(LocalDate dateLowRange, LocalDate dateHighRange);
    VehicleDTO addVehicle(VehicleDTO vehicleEntity);
}
