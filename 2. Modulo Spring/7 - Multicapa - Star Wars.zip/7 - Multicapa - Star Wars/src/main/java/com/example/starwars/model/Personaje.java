package com.example.starwars.model;


import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Personaje {
    private String name;
    private int height;
    private int mass;
    private String hairColor;
    private String skinColor;
    private String eyeColor;
    private String birthYear;
    private String gender;
    private String homeworld;
    private String species;

    public Personaje(String name, int height, int mass, String hairColor, String skinColor, String eyeColor, String birthYear, String gender, String homeWorld, String species) {
        this.name = name;
        this.height = height;
        this.mass = mass;
        this.hairColor = hairColor;
        this.skinColor = skinColor;
        this.eyeColor = eyeColor;
        this.birthYear = birthYear;
        this.gender = gender;
        this.homeworld = homeWorld;
        this.species = species;
    }

}
