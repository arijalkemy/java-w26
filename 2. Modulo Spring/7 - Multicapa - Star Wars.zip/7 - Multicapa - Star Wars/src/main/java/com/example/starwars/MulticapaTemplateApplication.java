package com.example.starwars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MulticapaTemplateApplication {

    public static void main(String[] args) {
        SpringApplication.run(MulticapaTemplateApplication.class, args);
    }

}
