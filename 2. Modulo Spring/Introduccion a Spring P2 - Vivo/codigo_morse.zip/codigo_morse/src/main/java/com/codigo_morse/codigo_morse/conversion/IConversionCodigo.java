package com.codigo_morse.codigo_morse.conversion;

public interface IConversionCodigo {
    public String decifrarLetraMorse(String morseCode);
    public String decifrarCadenaMorse(String morseStringCode);
    public String convertirAMorse(String cadena);
}
