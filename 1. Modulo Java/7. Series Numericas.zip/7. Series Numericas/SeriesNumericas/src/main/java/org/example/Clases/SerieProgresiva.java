package org.example.Clases;

public class SerieProgresiva<T extends Float> extends Prototipo{
    public SerieProgresiva(Double valorInicial) {
        super(valorInicial);
    }


}
