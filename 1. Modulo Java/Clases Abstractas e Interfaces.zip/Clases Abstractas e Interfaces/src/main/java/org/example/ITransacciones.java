package org.example;

public interface ITransacciones {

    void transaccionOK();
    void transaccionNoOk();
}
