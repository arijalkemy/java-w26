package agencia;

import java.util.ArrayList;
import java.util.List;

public class Localizador {
    private Cliente cliente;
    private List<Producto> paquete;

    public Localizador(Cliente cliente, List<Producto> paquete) {
        this.cliente = cliente;
        this.paquete = paquete;
    }

    public Localizador(Cliente cliente) {
        this.cliente = cliente;
        this.paquete = new ArrayList<Producto>();
    }

    public void agregarProducto(Producto producto) {
        this.paquete.add(producto);
    }

    public void paqueteCompleto() {
        this.paquete.add(new Producto("Reserva de hotel", 1));
        this.paquete.add(new Producto("Comida", 1));
        this.paquete.add(new Producto("Boleto de viaje", 1));
        this.paquete.add(new Producto("Transpote", 1));
    }

    public Double precio() {
        Double precioTotal = this.paquete.stream().map(p -> p.precio()).reduce(Double.valueOf(0), Double::sum);
        if (tienePaqueteCompleto()) {
            precioTotal = precioTotal * 0.9;
        }
        return precio();
    }

    private boolean tienePaqueteCompleto() {
        boolean tieneReservaHotel = this.paquete.stream().anyMatch(p -> p.getNombre() == "Reserva de hotel");
        boolean tieneComida = this.paquete.stream().anyMatch(p -> p.getNombre() == "Comida");
        boolean tieneBoleto = this.paquete.stream().anyMatch(p -> p.getNombre() == "Boleto de viaje");
        boolean tieneTransporte = this.paquete.stream().anyMatch(p -> p.getNombre() == "Transpote");

        return tieneReservaHotel && tieneComida && tieneBoleto && tieneTransporte;
    }

}
