package agencia;

public class Main {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("11222333", "Juan Lopez");
        Localizador localizador = new Localizador(cliente);
        localizador.paqueteCompleto();

    }
}
