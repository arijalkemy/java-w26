package agencia;

import java.util.Map;

public class Producto {
    private String nombre;

    public String getNombre() {
        return nombre;
    }

    private int cantidad;

    private final Map<String, Double> precios = Map.of(
            "Reserva de hotel", Double.valueOf(15),
            "Comida", Double.valueOf(15),
            "Reserva de hotel", Double.valueOf(15),
            "Reserva de hotel", Double.valueOf(15)
    );

    public Producto(String nombre,  int cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    public Double precio() {
        return precios.get(this.nombre);
    }
}

