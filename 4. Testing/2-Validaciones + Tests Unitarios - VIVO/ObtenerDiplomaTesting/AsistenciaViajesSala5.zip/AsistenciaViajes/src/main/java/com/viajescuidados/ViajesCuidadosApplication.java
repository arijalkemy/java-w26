package com.viajescuidados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViajesCuidadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViajesCuidadosApplication.class, args);
	}

}
