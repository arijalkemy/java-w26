package com.viajescuidados.entities.viajes;

public enum EstadoViaje {
    NO_INICIADO,
    EN_PROCESO,
    FINALIZADO
}
