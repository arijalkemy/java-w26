package com.viajescuidados.services.interfaces;

import com.viajescuidados.entities.Persona;

public interface IPersonaServiceInternal {
    Persona buscarPersonaPorId(Integer id);
}
