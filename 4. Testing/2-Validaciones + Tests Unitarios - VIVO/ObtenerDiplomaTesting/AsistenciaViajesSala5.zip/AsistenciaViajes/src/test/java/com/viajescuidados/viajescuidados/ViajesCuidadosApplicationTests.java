package com.viajescuidados.viajescuidados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViajesCuidadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
