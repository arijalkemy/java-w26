package com.mercadolibre.fresh_market.service;

import com.mercadolibre.fresh_market.model.User;
import org.springframework.stereotype.Service;

@Service
public interface IUserService extends IGenericService<User>{
}
