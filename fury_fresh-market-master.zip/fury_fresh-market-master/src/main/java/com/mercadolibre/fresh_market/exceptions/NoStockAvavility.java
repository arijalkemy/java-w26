package com.mercadolibre.fresh_market.exceptions;

public class NoStockAvavility extends RuntimeException{
    public NoStockAvavility(String message) {
        super(message);
    }
}
