package org.responseentity.elasticspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
