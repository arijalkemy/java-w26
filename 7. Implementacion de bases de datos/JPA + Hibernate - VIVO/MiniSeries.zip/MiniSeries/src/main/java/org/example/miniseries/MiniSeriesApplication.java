package org.example.miniseries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniSeriesApplication {

    public static void main(String[] args) {
        SpringApplication.run(MiniSeriesApplication.class, args);
    }

}
