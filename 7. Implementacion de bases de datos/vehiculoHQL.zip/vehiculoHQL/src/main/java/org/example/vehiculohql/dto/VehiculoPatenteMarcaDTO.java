package org.example.vehiculohql.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class VehiculoPatenteMarcaDTO {
    private String patente;
    private String marca;
}
