package com.example.consultashql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultasHqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
