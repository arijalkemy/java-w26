package com.example.consultashql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsultasHqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConsultasHqlApplication.class, args);
    }

}
