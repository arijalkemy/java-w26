package com.mercadolibre.concesionaria.projections;

public interface PatenteYMarca {
    String getPatente();
    String getMarca();
}