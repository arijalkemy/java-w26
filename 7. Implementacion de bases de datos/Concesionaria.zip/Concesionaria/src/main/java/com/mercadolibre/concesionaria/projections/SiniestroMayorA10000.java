package com.mercadolibre.concesionaria.projections;

public interface SiniestroMayorA10000 {
    String getPatente();
    String getMarca();
    String getModelo();
}
