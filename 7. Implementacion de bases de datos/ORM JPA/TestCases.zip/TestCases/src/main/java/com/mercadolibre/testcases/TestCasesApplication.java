package com.mercadolibre.testcases;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestCasesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestCasesApplication.class, args);
	}

}
