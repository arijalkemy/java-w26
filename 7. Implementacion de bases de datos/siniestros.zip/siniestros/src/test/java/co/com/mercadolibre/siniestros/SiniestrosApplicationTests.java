package co.com.mercadolibre.siniestros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiniestrosApplicationTests {

    @Test
    void contextLoads() {
    }

}
