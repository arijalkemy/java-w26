package co.com.mercadolibre.siniestros.dto;

public record SumaDTO(String patente, String marca, String modelo, Integer suma) {
}
