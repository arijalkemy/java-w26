package co.com.mercadolibre.siniestros.entity.projection;

public interface VehiculoProjection {
    String getMarca();
    String getModelo();
    String getPatente();
}
