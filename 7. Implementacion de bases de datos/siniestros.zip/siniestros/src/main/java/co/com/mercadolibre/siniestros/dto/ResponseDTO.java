package co.com.mercadolibre.siniestros.dto;

public record ResponseDTO(String marca, String modelo, String patente) {
}
