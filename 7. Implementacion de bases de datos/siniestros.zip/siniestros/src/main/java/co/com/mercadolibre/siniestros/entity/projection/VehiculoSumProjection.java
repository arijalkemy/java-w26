package co.com.mercadolibre.siniestros.entity.projection;

public interface VehiculoSumProjection {
    String getPatente();
    String getMarca();
    String getModelo();
    Integer getSuma();
}
