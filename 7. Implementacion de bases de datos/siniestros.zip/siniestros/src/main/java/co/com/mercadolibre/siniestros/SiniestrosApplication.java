package co.com.mercadolibre.siniestros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiniestrosApplication {

    public static void main(String[] args) {
        SpringApplication.run(SiniestrosApplication.class, args);
    }

}
