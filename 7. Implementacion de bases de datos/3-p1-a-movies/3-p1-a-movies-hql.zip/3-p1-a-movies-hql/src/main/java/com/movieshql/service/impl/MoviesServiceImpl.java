package com.movieshql.service.impl;

public class MoviesServiceImpl {
}
