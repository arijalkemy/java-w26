package com.movieshql.service;

public interface MoviesService {
}
