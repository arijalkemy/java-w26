package com.movieshql.controller;

public class MoviesController {
}
