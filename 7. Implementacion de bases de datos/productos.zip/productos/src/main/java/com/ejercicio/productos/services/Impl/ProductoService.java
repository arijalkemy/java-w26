package com.ejercicio.productos.services.Impl;

import org.springframework.stereotype.Service;

import com.ejercicio.productos.repositories.IProductoRepository;

@Service
public class ProductoService implements IProductoRepository{
    
}
