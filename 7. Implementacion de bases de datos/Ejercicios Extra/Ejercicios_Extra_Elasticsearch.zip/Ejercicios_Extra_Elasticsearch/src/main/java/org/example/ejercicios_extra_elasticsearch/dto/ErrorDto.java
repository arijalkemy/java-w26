package org.example.ejercicios_extra_elasticsearch.dto;

import lombok.Value;

@Value
public class ErrorDto {
    String mensaje;
}
