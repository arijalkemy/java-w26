package org.example.ejercicios_extra_elasticsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjerciciosExtraElasticsearchApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjerciciosExtraElasticsearchApplication.class, args);
    }

}
