package org.example.ejercicios_extra_bd_relacional.exception;

public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }
}
