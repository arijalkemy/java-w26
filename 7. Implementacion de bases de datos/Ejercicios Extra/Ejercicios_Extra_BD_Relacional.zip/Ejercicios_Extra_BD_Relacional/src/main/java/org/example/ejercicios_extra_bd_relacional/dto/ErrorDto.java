package org.example.ejercicios_extra_bd_relacional.dto;

import lombok.Value;

@Value
public class ErrorDto {
    String mensaje;
}
