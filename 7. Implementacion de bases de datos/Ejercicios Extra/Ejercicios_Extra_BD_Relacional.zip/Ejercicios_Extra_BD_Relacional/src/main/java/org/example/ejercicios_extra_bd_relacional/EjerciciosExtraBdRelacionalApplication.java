package org.example.ejercicios_extra_bd_relacional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjerciciosExtraBdRelacionalApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjerciciosExtraBdRelacionalApplication.class, args);
    }

}
