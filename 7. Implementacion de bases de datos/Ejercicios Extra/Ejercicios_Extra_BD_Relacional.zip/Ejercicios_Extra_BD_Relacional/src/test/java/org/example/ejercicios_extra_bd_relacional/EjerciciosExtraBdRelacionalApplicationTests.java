package org.example.ejercicios_extra_bd_relacional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciosExtraBdRelacionalApplicationTests {

    @Test
    void contextLoads() {
    }

}
