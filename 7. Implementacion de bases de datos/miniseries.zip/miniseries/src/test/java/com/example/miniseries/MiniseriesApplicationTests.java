package com.example.miniseries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniseriesApplicationTests {

    @Test
    void contextLoads() {
    }

}
