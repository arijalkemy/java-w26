package com.example.miniseries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniseriesApplication {

    public static void main(String[] args) {
        SpringApplication.run(MiniseriesApplication.class, args);
    }

}
