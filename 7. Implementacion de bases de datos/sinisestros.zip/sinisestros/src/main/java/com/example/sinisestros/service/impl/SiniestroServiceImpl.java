package com.example.sinisestros.service.impl;

import com.example.sinisestros.dto.VehiculoPatMarModDto;
import com.example.sinisestros.repository.ISiniestroRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SiniestroServiceImpl {

    private ISiniestroRepository siniestroRepository;

    public SiniestroServiceImpl(ISiniestroRepository siniestroRepository){
        this.siniestroRepository = siniestroRepository;
    }

    //Listar la matrícula, marca y modelo de todos los vehículos que hayan tenido un
    // siniestro con pérdida mayor de 10000 pesos.

    //public List<VehiculoPatMarModDto> get



    //Listar la matrícula, marca y modelo de todos los vehículos que hayan tenido un siniestro con pérdida
    // mayor de 10000 pesos y mostrar a cuánto ascendió la pérdida total de todos ellos


}
