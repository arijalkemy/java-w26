package com.example.sinisestros.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VehiculoPatMarModDto {
    private String patente;
    private String marca;
    private String modelo;
}
