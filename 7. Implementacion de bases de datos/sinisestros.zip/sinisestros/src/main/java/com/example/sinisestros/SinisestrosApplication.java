package com.example.sinisestros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SinisestrosApplication {

    public static void main(String[] args) {
        SpringApplication.run(SinisestrosApplication.class, args);
    }

}
