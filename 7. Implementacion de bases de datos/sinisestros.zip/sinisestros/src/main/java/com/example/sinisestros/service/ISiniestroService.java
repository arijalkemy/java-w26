package com.example.sinisestros.service;

public interface ISiniestroService {
}
