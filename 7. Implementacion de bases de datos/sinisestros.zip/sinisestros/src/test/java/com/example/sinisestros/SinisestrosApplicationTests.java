package com.example.sinisestros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SinisestrosApplicationTests {

    @Test
    void contextLoads() {
    }

}
