package com.empleadoselastic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpleadosElasticApplicationTests {

    @Test
    void contextLoads() {
    }

}
