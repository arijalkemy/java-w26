package com.empleadoselastic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpleadosElasticApplication {

    public static void main(String[] args) {
        SpringApplication.run(
                EmpleadosElasticApplication.class,
                args
        );
    }

}
