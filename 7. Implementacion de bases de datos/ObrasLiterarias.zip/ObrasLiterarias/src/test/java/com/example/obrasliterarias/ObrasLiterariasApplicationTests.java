package com.example.obrasliterarias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObrasLiterariasApplicationTests {

    @Test
    void contextLoads() {
    }

}
