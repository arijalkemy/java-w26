package com.example.obrasliterarias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObrasLiterariasApplication {

    public static void main(String[] args) {
        SpringApplication.run(ObrasLiterariasApplication.class, args);
    }

}
