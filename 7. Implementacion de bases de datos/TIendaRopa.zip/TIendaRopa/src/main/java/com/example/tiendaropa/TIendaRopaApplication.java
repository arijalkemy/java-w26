package com.example.tiendaropa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TIendaRopaApplication {

    public static void main(String[] args) {
        SpringApplication.run(TIendaRopaApplication.class, args);
    }

}
