package com.bootcamp.JPAImplementation.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StudentRequestDTO {
    private String identification;
    private String name;
    private String lastName;
}
