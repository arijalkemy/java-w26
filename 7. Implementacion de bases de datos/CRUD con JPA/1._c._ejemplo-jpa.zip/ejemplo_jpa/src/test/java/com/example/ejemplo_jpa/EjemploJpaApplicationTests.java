package com.example.ejemplo_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
