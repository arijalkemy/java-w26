package com.example.showroom.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InfoMessageDto {
    private String message;
}
