package com.mercadolibre.moviesHQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesHqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
