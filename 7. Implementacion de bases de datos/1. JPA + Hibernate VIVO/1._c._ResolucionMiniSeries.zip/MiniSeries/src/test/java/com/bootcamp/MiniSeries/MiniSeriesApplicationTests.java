package com.bootcamp.MiniSeries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniSeriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
