package com.bootcamp.JPAImplementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaImplementationApplicationTests {

	@Test
	void contextLoads() {
	}

}
