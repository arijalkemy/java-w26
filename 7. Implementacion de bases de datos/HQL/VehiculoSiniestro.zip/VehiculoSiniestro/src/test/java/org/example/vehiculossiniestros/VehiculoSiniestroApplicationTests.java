package org.example.vehiculossiniestros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiculoSiniestroApplicationTests {

    @Test
    void contextLoads() {
    }

}
