package org.example.vehiculossiniestros.dto;

public record PatenteAndMarcaDTO(String patente, String marca) {
}
