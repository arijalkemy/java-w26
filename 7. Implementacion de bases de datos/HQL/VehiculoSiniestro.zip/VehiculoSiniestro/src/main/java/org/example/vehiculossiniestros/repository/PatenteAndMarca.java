package org.example.vehiculossiniestros.repository;

public interface PatenteAndMarca {
    String getPatente();
    String getMarca();
}
