package org.example.vehiculossiniestros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehiculoSiniestroApplication {

    public static void main(String[] args) {
        SpringApplication.run(VehiculoSiniestroApplication.class, args);
    }

}
