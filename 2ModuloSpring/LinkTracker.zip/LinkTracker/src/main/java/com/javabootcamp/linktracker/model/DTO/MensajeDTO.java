package com.javabootcamp.linktracker.model.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MensajeDTO {
    private String mensajeDelServidor;
}
