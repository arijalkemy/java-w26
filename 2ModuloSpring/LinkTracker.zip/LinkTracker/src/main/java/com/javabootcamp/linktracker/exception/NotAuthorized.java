package com.javabootcamp.linktracker.exception;

public class NotAuthorized extends RuntimeException{
}
