package com.bootcampjava.blogapirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogApiRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
