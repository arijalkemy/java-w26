package com.bootcampjava.blogapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogApiRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(BlogApiRestApplication.class, args);
    }

}
