package com.bootcampjava.blogapirest.exception;

public class ExisteEntradaException extends RuntimeException{
    public ExisteEntradaException(String message) {
        super(message);
    }
}
