package com.mercadolibre.fresh_market.exceptions;

public class StatusInvalidException extends RuntimeException {
        public StatusInvalidException(String message) {
            super(message);
        }
}
