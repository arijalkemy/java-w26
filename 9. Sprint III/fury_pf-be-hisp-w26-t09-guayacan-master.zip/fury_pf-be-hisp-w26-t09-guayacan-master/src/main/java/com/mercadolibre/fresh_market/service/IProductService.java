package com.mercadolibre.fresh_market.service;

import com.mercadolibre.fresh_market.dtos.*;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;

public interface IProductService {
    ProductStockDTO getProductStock(Long productId);

    List<ProductDetailDTO> getAllProducts();

    List<ProductDetailDTO> getAllProductsByCategory(String category);

    OperationResponseDTO createProducts(Long idSeller, ProductRequestDTO productsDTO);

    OperationResponseDTO updateProduct(Long idSeller, Long idProduct, ProductRequestDetailDTO productDetailDTO);
}
