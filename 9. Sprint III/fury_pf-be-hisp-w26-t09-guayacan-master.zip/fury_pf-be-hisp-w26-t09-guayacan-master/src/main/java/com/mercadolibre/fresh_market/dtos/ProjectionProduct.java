package com.mercadolibre.fresh_market.dtos;

public record ProjectionProduct(Long id, Double price, String description) {
    
}
