package com.mercadolibre.fresh_market.controller;


import com.mercadolibre.fresh_market.dtos.*;
import com.mercadolibre.fresh_market.service.impl.ProductService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class ProductControllerTest {

    @Mock
    private ProductService productService;

    @InjectMocks
    private ProductController productController;

    @Test
    public void testCreateProducts() {
        Long idSeller = 1L;
        ProductRequestDTO productRequestDTO = new ProductRequestDTO();
        OperationResponseDTO operationResponseDTO = new OperationResponseDTO();
        when(productService.createProducts(idSeller, productRequestDTO)).thenReturn(operationResponseDTO);

        ResponseEntity<OperationResponseDTO> response = productController.postCreateProduct(idSeller, productRequestDTO);
        assertEquals(operationResponseDTO, response.getBody());
    }

    @Test
    public void testUpdateProduct() {
        Long idSeller = 1L;
        Long idProduct = 1L;
        ProductRequestDetailDTO productDetailDTO = new ProductRequestDetailDTO();
        OperationResponseDTO operationResponseDTO = new OperationResponseDTO();
        when(productService.updateProduct(idSeller, idProduct, productDetailDTO)).thenReturn(operationResponseDTO);

        ResponseEntity<OperationResponseDTO> response = productController.putUpdateProduct(idSeller, idProduct, productDetailDTO);
        assertEquals(operationResponseDTO, response.getBody());
    }
}
