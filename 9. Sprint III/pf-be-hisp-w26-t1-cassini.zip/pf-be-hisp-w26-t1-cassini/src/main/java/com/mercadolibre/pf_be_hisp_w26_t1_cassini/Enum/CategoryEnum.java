package com.mercadolibre.pf_be_hisp_w26_t1_cassini.Enum;

public enum CategoryEnum {
    FS,
    RF,
    FF
}
