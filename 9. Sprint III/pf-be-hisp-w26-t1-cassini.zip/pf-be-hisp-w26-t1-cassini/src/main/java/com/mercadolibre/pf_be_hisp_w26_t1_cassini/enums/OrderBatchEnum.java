package com.mercadolibre.pf_be_hisp_w26_t1_cassini.enums;

public enum OrderBatchEnum {
    L,
    T,
    C
}
