package com.mercadolibre.pf_be_hisp_w26_t09_gomez.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.UserDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.enums.Role;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.repository.IUserRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class AuthControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Mock
    private IUserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    ObjectWriter writer = new ObjectMapper().configure(SerializationFeature.WRAP_ROOT_VALUE, false).writer();

    @Test
    public void testRegisterSuccessful() throws Exception {
        UserDTO userDto = new UserDTO();
        userDto.setFirstName("John");
        userDto.setLastName("Doe");
        userDto.setEmail("john.doe1@email.com");
        userDto.setPassword("password123");
        userDto.setAddress("123 Street");
        userDto.setRole(Role.WAREHOUSEMAN);

        String expected = writer.writeValueAsString(userDto);

        when(userRepository.findUserByEmail(userDto.getEmail())).thenReturn(null);

        when(passwordEncoder.encode(userDto.getPassword())).thenReturn("hashedPassword");

        MvcResult mvcResult = mockMvc.perform(post("/api/v1/fresh-products/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(userDto)))
                .andExpect(status().isCreated())
                .andReturn();

        String actual = mvcResult.getResponse().getContentAsString();

        assertEquals(expected, actual);
    }
}