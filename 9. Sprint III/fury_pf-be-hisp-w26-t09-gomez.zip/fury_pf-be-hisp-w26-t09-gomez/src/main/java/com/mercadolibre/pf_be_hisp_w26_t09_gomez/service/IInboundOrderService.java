package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.BatchDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.InboundOrderReqDTO;

import java.util.List;

public interface IInboundOrderService {
    List<BatchDTO> createInboundOrder(InboundOrderReqDTO inboundOrderReqDTO);
    List<BatchDTO> updateInboundOrder(Long id, InboundOrderReqDTO inboundOrderReqDTO);
}
