package com.mercadolibre.pf_be_hisp_w26_t09_gomez.exceptions;

public class NoStockAvavility extends RuntimeException{
    public NoStockAvavility(String message) {
        super(message);
    }
}
