package com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseJWTDTO {
    private String token;
}
