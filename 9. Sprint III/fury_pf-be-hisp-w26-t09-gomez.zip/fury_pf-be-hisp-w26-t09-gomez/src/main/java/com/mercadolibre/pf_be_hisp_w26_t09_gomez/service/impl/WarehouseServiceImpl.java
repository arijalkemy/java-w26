package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service.impl;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.WarehouseDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.Warehouse;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.repository.IWarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WarehouseServiceImpl {
    @Autowired
    IWarehouseRepository warehouseRepository;

    public WarehouseDTO getWarehouseByWarehousemanId(Long warehousemanId) {
        Warehouse warehouse = warehouseRepository.findWarehouseByWarehousemanId(warehousemanId);
        return new WarehouseDTO(warehouse.getId());
    }
}
