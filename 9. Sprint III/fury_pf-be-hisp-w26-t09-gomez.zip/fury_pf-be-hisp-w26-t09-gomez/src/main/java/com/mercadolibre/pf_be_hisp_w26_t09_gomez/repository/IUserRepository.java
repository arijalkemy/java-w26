package com.mercadolibre.pf_be_hisp_w26_t09_gomez.repository;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IUserRepository extends JpaRepository<User, Long> {
    Optional<User> findUserByEmail(String email);
}
