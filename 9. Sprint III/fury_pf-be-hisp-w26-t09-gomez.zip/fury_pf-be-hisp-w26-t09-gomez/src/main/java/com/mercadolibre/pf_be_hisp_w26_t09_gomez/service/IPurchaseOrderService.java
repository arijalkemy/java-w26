package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service;



import org.springframework.security.core.userdetails.UserDetails;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.ProjectionPurchaseOrder;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.PurchaseOrderDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.Response;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.ResponseDTO;

public interface IPurchaseOrderService {

    ResponseDTO modifyOrderExistence(Long orderId, PurchaseOrderDTO purchaseOrderDTO);
    Response createPurcharseOrder(PurchaseOrderDTO purchaseOrderDTO, UserDetails userDetails);
    ProjectionPurchaseOrder getProductsByPurchaseOrder(Long idOrder);
}
