package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.User;
import org.springframework.stereotype.Service;

@Service
public interface IUserService extends IGenericService<User>{
}
