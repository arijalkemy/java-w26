package com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Category {
    FF(1, "Frozen"),
    RF(2, "Cooled"),
    FS(3, "Fresh");

    private Integer id;
    private String name;

    public Integer getId() {
        return id;
    }
}
