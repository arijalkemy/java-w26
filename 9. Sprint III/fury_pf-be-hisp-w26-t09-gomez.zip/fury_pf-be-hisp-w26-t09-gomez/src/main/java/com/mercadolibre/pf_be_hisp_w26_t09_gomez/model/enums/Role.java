package com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Role {
    WAREHOUSEMAN("Warehouseman"),
    BUYER("Buyer"),
    SELLER("Seller");
    private String name;
}
