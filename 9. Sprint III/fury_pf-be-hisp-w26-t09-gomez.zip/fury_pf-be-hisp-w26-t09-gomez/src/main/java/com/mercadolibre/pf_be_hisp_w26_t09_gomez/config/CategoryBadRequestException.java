package com.mercadolibre.pf_be_hisp_w26_t09_gomez.config;

public class CategoryBadRequestException extends RuntimeException{
    public CategoryBadRequestException(String message) {
        super(message);
    }
}
