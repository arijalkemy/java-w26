package com.mercadolibre.pf_be_hisp_w26_t09_gomez.repository;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.CartDetail;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.ShoppingCartKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ICartDetailRepository extends JpaRepository<CartDetail, ShoppingCartKey>{
    List<CartDetail> findById_OrderId(Long orderId);
}
