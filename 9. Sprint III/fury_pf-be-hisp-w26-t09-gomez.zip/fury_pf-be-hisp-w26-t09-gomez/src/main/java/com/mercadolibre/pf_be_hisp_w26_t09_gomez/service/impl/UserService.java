package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service.impl;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.exceptions.EntityNotFound;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.User;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.repository.IUserRepository;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private IUserRepository userRepository;

    
    public User getUserByEmail(String email) {

        Optional<User> optionalUser = userRepository.findUserByEmail(email);
        
        if (!optionalUser.isPresent()) {
            throw new EntityNotFound("The user with username: " + email + " was not found.");
        }


        return optionalUser.get();
    }

}
