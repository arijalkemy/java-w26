package com.mercadolibre.pf_be_hisp_w26_t09_gomez.util.mapper;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.ProductDetailDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.Product;

public class ProductMapper {
    public ProductDetailDTO productToProductDetailDTO(Product product){
        return ProductDetailDTO.builder()
                .id(product.getId())
                .description(product.getDescription())
                .price(product.getPrice())
                .build();
    }

    public Product productDetailDTOToProduct(ProductDetailDTO product){
        return Product.builder()
                .id(product.getId())
                .description(product.getDescription())
                .price(product.getPrice())
                .build();
    }
}
