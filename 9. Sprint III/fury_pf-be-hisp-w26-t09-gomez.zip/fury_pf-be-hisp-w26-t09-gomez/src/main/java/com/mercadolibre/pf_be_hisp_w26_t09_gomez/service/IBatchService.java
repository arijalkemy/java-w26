package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.BatchLocationResponseDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.ExpiringProductResponseDTO;

public interface IBatchService {

    ExpiringProductResponseDTO getBatchesExpiringSoon(Integer countDays);

    ExpiringProductResponseDTO getBatchesExpiringSoonByCategoryAndOrder(Integer countDays, String category,
                                                                        String order);


    BatchLocationResponseDTO getBatchByProductId(Long idProduct);
    BatchLocationResponseDTO getBatchByProductIdOrdered(Long idProduct, String order);

}
