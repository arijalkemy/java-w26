package com.mercadolibre.pf_be_hisp_w26_t09_gomez.exceptions;

public class StatusInvalidException extends RuntimeException {
        public StatusInvalidException(String message) {
            super(message);
        }
}
