package com.mercadolibre.pf_be_hisp_w26_t09_gomez.config;

public class ProductsNotFoundException extends RuntimeException{
    public ProductsNotFoundException(String message) {
        super(message);
    }
}
