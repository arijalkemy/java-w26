package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service;

import java.util.List;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.ProductDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.Product;

public interface IPurchaseOrderValidationService {
   public List<Product> validateExistenceProducts(List<ProductDTO> listProductsToValidate);
   public Double validateStock(List<Product> products, List<ProductDTO> productsToValidate);
}
