package com.mercadolibre.pf_be_hisp_w26_t09_gomez.exceptions;

public class UnauthorizedAccessException extends RuntimeException {

    public UnauthorizedAccessException(String message) { super(message); }
}
