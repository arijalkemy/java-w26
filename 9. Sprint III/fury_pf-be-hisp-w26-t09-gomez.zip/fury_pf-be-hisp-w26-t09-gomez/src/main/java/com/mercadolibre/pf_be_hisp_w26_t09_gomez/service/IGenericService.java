package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service;

import java.util.List;

/**
 * Interface for generic service
 *
 * @param <T> Entity
 * @author jsanchezpimi
 **/
public interface IGenericService<T> {
    T findById(Long id);
    List<T> findAll();
    T save(T t);
    T update(Long id, T t);
    void delete(Long id);
}
