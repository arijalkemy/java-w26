package com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.ShoppingCartKey;

import lombok.Builder;

@Builder
public record ProjectionCartDetail(String description, ShoppingCartKey id, Integer quantity, ProjectionProduct product) {
}
