package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.WarehouseDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.Warehouse;

public interface IWarehouseService extends IGenericService<Warehouse> {
    WarehouseDTO getWarehouseByWarehousemanId(Long warehousemanId);
}
