package com.mercadolibre.pf_be_hisp_w26_t09_gomez.repository;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.InboundOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IInboundOrderRepository extends JpaRepository<InboundOrder,Long> {
}
