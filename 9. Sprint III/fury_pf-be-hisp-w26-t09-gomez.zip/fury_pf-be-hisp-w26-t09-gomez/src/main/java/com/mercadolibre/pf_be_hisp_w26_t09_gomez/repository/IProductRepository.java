package com.mercadolibre.pf_be_hisp_w26_t09_gomez.repository;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IProductRepository extends JpaRepository<Product,Long> {
    List<Product> findAll();
}
