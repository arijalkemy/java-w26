package com.mercadolibre.pf_be_hisp_w26_t09_gomez.service;

import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.OperationResponseDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.ProductDetailDTO;
import com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos.ProductStockDTO;

import java.util.List;

public interface IProductService {
    ProductStockDTO getProductStock(Long productId);
    List<ProductDetailDTO> getAllProducts();
    List<ProductDetailDTO> getAllProductsByCategory(String category);
    OperationResponseDTO createProduct (List<ProductDetailDTO> productsDTO, Long idSeller);
    OperationResponseDTO updateProduct(Long idSeller, Long idProduct, ProductDetailDTO productDetailDTO);
}
