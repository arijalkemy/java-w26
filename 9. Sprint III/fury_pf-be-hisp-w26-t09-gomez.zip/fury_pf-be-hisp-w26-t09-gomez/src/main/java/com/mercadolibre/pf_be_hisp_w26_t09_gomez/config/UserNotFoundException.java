package com.mercadolibre.pf_be_hisp_w26_t09_gomez.config;

public class UserNotFoundException extends RuntimeException{
        public UserNotFoundException(String message) {
            super(message);
        }
}
