package com.mercadolibre.pf_be_hisp_w26_t09_gomez.dtos;

public record ProjectionProduct(Long id, Double price, String description) {
    
}
