package com.mercadolibre.pf_be_hisp_w26_t09_gomez.exceptions;

import org.springframework.http.HttpStatus;

public class EntityNotFound extends ApiException {

    public EntityNotFound(String description) {
        super("Entity not found.", description, HttpStatus.NOT_FOUND.value());
    }
    
}
