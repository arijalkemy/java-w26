package com.mercadolibre.pf_be_hisp_w26_t09_gomez.config;

public class BadRequestException extends RuntimeException{
    public BadRequestException(String message) {
        super(message);
    }
}