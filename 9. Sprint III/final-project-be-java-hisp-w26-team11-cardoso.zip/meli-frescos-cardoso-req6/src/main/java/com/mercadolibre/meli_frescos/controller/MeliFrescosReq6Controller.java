package com.mercadolibre.meli_frescos.controller;

import com.mercadolibre.meli_frescos.dto.frescos.*;
import com.mercadolibre.meli_frescos.service.IMeliFrescosService;
import jakarta.validation.constraints.Min;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1")
@Validated
public class MeliFrescosReq6Controller {

    @Autowired
    IMeliFrescosService service;

    /**
     * Busca productos por nombre y rango de precios.
     *
     * @param name     Nombre del producto (opcional).
     * @param minPrice Precio mínimo (opcional).
     * @param maxPrice Precio máximo (opcional).
     * @return Lista de productos que coinciden con los criterios de búsqueda.
     */
    @GetMapping("/fresh-products/search")
    public ResponseEntity<List<ProductResponsePriceDTO>> searchProducts(
            @RequestParam Optional<String> name,
            @RequestParam Optional<Double> minPrice,
            @RequestParam Optional<Double> maxPrice) {
        List<ProductResponsePriceDTO> products = service.searchProducts(name, minPrice, maxPrice);
        return ResponseEntity.ok(products);
    }

    /**
     * Obtiene productos con stock por debajo de un umbral especificado.
     *
     * @param threshold Umbral de stock mínimo.
     * @return Lista de productos con stock bajo.
     */
    @GetMapping("/fresh-products/low-stock")
    public ResponseEntity<List<ProductLowStockResponseDTO>> getLowStockProducts(
            @RequestParam @Min(value = 1, message = "El umbral de stock debe ser al menos 1") Integer threshold) {
        List<ProductLowStockResponseDTO> products = service.getLowStockProducts(threshold);
        return ResponseEntity.ok(products);
    }
}
