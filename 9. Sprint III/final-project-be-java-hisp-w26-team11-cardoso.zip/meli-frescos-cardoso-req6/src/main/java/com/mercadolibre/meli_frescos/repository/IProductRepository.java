package com.mercadolibre.meli_frescos.repository;


import com.mercadolibre.meli_frescos.dto.frescos.ProductLowStockResponseDTO;
import com.mercadolibre.meli_frescos.dto.frescos.ProductSimpleResponseDTO;
import com.mercadolibre.meli_frescos.model.Product;
import com.mercadolibre.meli_frescos.dto.frescos.WarehouseDTO;
import com.mercadolibre.meli_frescos.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IProductRepository extends JpaRepository<Product,Integer> {
    @Override
    List<Product> findAllById(Iterable<Integer> longs);
    @Query("SELECT new com.mercadolibre.meli_frescos.dto.frescos.WarehouseDTO(w.warehouseCode, SUM(b.currentQuantity)) " +
           "FROM Product p JOIN p.batches b JOIN b.section s JOIN s.warehouse w " +
           "WHERE p.id = :id " +
           "GROUP BY w.warehouseCode")
    List<WarehouseDTO> findWarehousesAndQuantitiesByProductId(@Param("id") Integer id);


    @Query("SELECT new com.mercadolibre.meli_frescos.dto.frescos.ProductSimpleResponseDTO( p.name, p.price )" +
            "FROM Product p" + " JOIN p.batches b " + "JOIN b.section s WHERE s.productType.acronym = :acronym"
    )
    List<ProductSimpleResponseDTO> findAllByProductTypeAcronym(String acronym);


    /**
     * Encuentra productos por nombre y rango de precios.
     *
     * @param name     Nombre del producto (opcional).
     * @param minPrice Precio mínimo (opcional).
     * @param maxPrice Precio máximo (opcional).
     * @return Lista de productos que coinciden con los criterios de búsqueda.
     */
    @Query("SELECT p FROM Product p WHERE (:name IS NULL OR p.name LIKE %:name%) " +
            "AND (:minPrice IS NULL OR p.price >= :minPrice) " +
            "AND (:maxPrice IS NULL OR p.price <= :maxPrice)")
    List<Product> findByNameAndPriceRange(@Param("name") String name,
                                          @Param("minPrice") Double minPrice,
                                          @Param("maxPrice") Double maxPrice);

    /**
     * Encuentra productos con stock por debajo de un umbral especificado.
     *
     * @param threshold Umbral de stock mínimo.
     * @return Lista de productos con stock bajo.
     */
    @Query("SELECT new com.mercadolibre.meli_frescos.dto.frescos.ProductLowStockResponseDTO(p.id, p.name, SUM(b.currentQuantity)) " +
            "FROM Product p JOIN p.batches b " +
            "GROUP BY p.id, p.name " +
            "HAVING SUM(b.currentQuantity) < :threshold")
    List<ProductLowStockResponseDTO> findByLowStock(@Param("threshold") Integer threshold);

}