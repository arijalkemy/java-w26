package com.mercadolibre.meli_frescos.model;

public enum Role {
    BUYER,
    SELLER,
    WAREHOUSE
}
